def es_numero_step(numero):
    numero = str(numero) 
    for i in range(len(numero) - 1):
        if abs(int(numero[i]) - int(numero[i+1])) != 1: 
            return False
    return True
print(es_numero_step(1234)) 
print(es_numero_step(9876)) 
print(es_numero_step(135)) 
print(es_numero_step(2018)) 
print(es_numero_step(444)) 