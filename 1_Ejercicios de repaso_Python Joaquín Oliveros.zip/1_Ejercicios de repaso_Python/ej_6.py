def contar_vocales(frase):
    vocales = 'aeiouAEIOU' 
    cantidad = 0
    for letra in frase:
        if letra in vocales:
            cantidad += 1
    return cantidad
print(contar_vocales('Hola amigo como andás')) 
print(contar_vocales('Talleres es el club más grande de Córdoba')) 
print(contar_vocales('Esta frase no tiene ninguna vocal')) 