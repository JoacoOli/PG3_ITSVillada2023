ancho_r = int(input("Ingrese el ancho del rectángulo: "))
alto_r = int(input("Ingrese el alto del rectángulo: "))
caracter_r = input("Ingrese el caracter a utilizar para el rectángulo: ")
ancho_t = int(input("Introduce el ancho del triángulo: "))
alto_t = int(input("Introduce el alto del triángulo: "))
caracter_t = input("Introduce el carácter a utilizar para el triángulo: ")

for i in range(alto_r):
    for j in range(ancho_r):
        if i == 0 or i == alto_r - 1 or j == 0 or j == ancho_r - 1:
            print(caracter_r, end=" ")
        else:
            print(" ", end=" ")
    print()

def dibujar_triangulo(ancho_t, alto_t, caracter_t):
    for i in range(alto_t):
        linea = caracter_t * (i + 1) 
        print(linea.center(ancho_t)) 

dibujar_triangulo(ancho_t, alto_t, caracter_t)