def ordenar_lista(lista):
    lista_ordenada = sorted(lista, reverse=True)
    return lista_ordenada
mi_lista = [2, 5, 10, 45, 21, 7]
lista_ordenada = ordenar_lista(mi_lista)
print(lista_ordenada)
