lista = ["Lorenzo", "Joaquin", "Eduardo", "Miguel", "Luca"] 

valor_buscar = input("Ingrese el nombre que desea buscar en la lista: ") 

if valor_buscar in lista: 
    indice = lista.index(valor_buscar) 
    print(f"El nombre {valor_buscar} se encuentra en la posición {indice} de la lista.")
else:
    print(f"El nombre {valor_buscar} no se encuentra en la lista.") 