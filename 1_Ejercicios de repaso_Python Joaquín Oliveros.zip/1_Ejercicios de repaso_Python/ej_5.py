def es_palindromo(palabra):
    palabra = palabra.lower() 
    palabra = palabra.replace(' ', '') 
    if palabra == palabra[::-1]: 
        return True
    else:
        return False
print(es_palindromo('reconocer')) 
print(es_palindromo('necio')) 
print(es_palindromo('radar')) 
print(es_palindromo('python')) 
print(es_palindromo('neuquen'))