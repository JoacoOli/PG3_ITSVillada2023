class Persona:
    def __init__(self, nombre):
        self.nombre = nombre
    
    def mostrar_nombre(self):
        print(self.nombre)

persona1 = Persona("Joaquín")
persona2 = Persona("Tobias")
persona1.mostrar_nombre()
persona2.mostrar_nombre()
